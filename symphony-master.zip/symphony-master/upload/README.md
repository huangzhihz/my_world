上传目录，可以通过 symphony.props 中的 `upload.dir=./upload/` 进行指定。
